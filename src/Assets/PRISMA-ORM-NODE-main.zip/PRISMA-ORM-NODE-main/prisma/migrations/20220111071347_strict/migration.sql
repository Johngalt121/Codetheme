-- AlterTable
ALTER TABLE "Users" ADD COLUMN     "role" TEXT;
