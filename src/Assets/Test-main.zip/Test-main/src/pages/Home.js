import React from 'react';
import { Button } from 'reactstrap';
const Home =()=>{
    return (
        <Button color="primary" className="btn-label"> <i className="ri-user-smile-line label-icon align-middle fs-16 me-2"></i> Primary </Button>
        )
}


export default Home