-- AlterTable
ALTER TABLE "Login" ALTER COLUMN "password" SET DATA TYPE TEXT;
