-- AlterTable
ALTER TABLE "Survey" ALTER COLUMN "date_of_survey" SET DATA TYPE TEXT;
